const express = require('express')
const routes = express.Router()

let valor = 0

routes.get('/', (req, res) => {
    res.sendFile(__dirname + '/sumario.html')
})

routes.get('/ex1', (req, res) => {
    res.sendFile(__dirname + '/ex1.html')
})

routes.post('/resultado', (req, res) => {
    dados = req.body
    calculo = Object.values(dados).reduce( (e, i) => {
        n1 = parseInt(e)
        n2 = parseInt(i)
        return total = n1 + n2
    })
    valor = calculo
    res.redirect('/resultado')
})

routes.get('/resultado', (req, res) => {
    res.send("valor: " +valor)
})


routes.get('/ex2', (req, res) =>{
    res.sendFile(__dirname + '/ex2.html')
})

routes.get('/resultado', (req, res) =>{
    let {n1, n2} = req.query
    valor = n1 - n2
    res.send("Resultado é: " + valor)
})
routes.post('/resultado', (req, res) =>{
    let {n1, n2} = req.body
    valor = parseInt(n1) + parseInt(n2)
    res.send("Resultado é: " + valor)
})

module.exports = routes